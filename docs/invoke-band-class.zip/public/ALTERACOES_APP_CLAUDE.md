# Alterações no app (base44) — handoff pro firmware

_Atualizado em 2026-09-06. O firmware está correto e verificado (nRF Connect +
`invoke-console` no mesmo Chrome). As mudanças abaixo são só no lado do app._

## 1. `src/lib/ble.js` — conexão refatorada

**Antes:** loop `connect → fail → disconnect → reconnect` que **ele mesmo
disparava o `0x3e`** no Android. Mensagem de erro falsa apontava
"firmware desatualizado / duty-cycle de scan".

**Agora (igual ao `apps/invoke-console/src/ble.ts`):**
- Caminho feliz: **um único** `gatt.connect()` + `getPrimaryService(NUS)`.
- Retry só em falha real: `disconnect()` completo + pausa ≥1.2s, máx 2 tentativas.
- Em falha total, faz `getPrimaryServices()` e lista o que o aparelho realmente
  expõe (em vez de array vazio silencioso).
- Mensagem honesta: _"Conexão instável ou cache GATT do Chrome — reset a
  permissão Bluetooth do site ou desligue/religue o Bluetooth."_

**Contrato BLE que o app espera do firmware (não mudou — manter):**

| Papel | UUID |
|---|---|
| Serviço NUS | `6e400001-b5a3-f393-e0a9-e50e24dcca9e` |
| RX (app→nó, WRITE) | `6e400002-b5a3-f393-e0a9-e50e24dcca9e` |
| TX (nó→app, NOTIFY) | `6e400003-b5a3-f393-e0a9-e50e24dcca9e` |

Payload RX (app→nó): JSON do disparo de questão
`{"t":"q","bands":["3","7"],"cd":5,"s":"...","o":{"up":"...","down":"...",...}}`.
Payload TX (nó→app): `{"b":"3","d":"up"}` (gesto) — o app aceita também o legado
`"3:up"` / `"up"`.

## 2. `connectMeshNode()` agora retorna o nº da pulseira

```js
const { send, stop, bandNumber } = await connectMeshNode(onGesture, onError);
```

O nº é extraído do **nome BLE do nó** (`INVOKE-xx` → `xx`), que o firmware já
monta com `snprintf(name, "INVOKE-%02u", g_band)` a partir do número cadastrado
no NVS.

**⚠️ Contrato de nome (manter no firmware):** o nome BLE DEVE seguir
`INVOKE-xx` onde `xx` é o número da pulseira em 2 dígitos. É dele que o app
extrai o nº cadastrado pra mostrar na tela de idle. Se o formato do nome mudar,
o app não consegue mais mostrar o número.

## 3. Tela de idle do wearable (`WatchPreview.jsx`)

O app agora renderiza uma tela de standby quando a pulseira não está em rodada
(fase `idle` — ao entrar na sessão e após cada questão). Layout:

```
┌──────────────┐
│  • PRONTA    │   ← ponto verde pulsante + "PRONTA"
│              │
│   INVOKE     │   ← wordmark
│  Pulseira #03│   ← nº cadastrado (do nome BLE do nó conectado)
│              │
│ AGUARDANDO   │   ← "AGUARDANDO PERGUNTA"
│  PERGUNTA    │
└──────────────┘
```

Isso é só o **preview no app** (o que o professor vê). Se o firmware quiser
espelhar esse mesmo layout no OLED/TFT físico da pulseira no estado IDLE, os
elementos são: status "PRONTA" + indicador, logo "INVOKE", nº da pulseira, e
"Aguardando pergunta".

## 4. Arquivos alterados

| Arquivo | O quê |
|---|---|
| `src/lib/ble.js` | Conexão GATT refatorada (connect único + retry limpo); retorna `bandNumber` do nome BLE. |
| `src/components/live/WatchPreview.jsx` | Nova fase `idle` (standby) com nº da pulseira. |
| `src/pages/Live.jsx` | Passa o `bandNumber` do nó conectado pro preview; limpa ao desconectar. |

## Nada que o firmware precise mudar

O firmware na `main` já está correto e compatível. Este doc é só pra alinhar
contratos (UUIDs, nome `INVOKE-xx`, payload do gesto) e o layout da tela de idle
caso queiram replicar no display físico.
