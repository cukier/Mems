import React from 'react';
import { Outlet, Link, useLocation } from 'react-router-dom';
import { LayoutDashboard, School, Users, GraduationCap, UserSquare2, HelpCircle, Watch, Radio, BarChart3, Trophy, Gamepad2, LogOut } from 'lucide-react';
import { base44 } from '@/api/base44Client';
import ThemeToggle from '@/components/ThemeToggle';

const NAV = [
  { to: '/', label: 'Painel', icon: LayoutDashboard },
  { to: '/live', label: 'Sessão', icon: Radio },
  { to: '/performance', label: 'Desempenho', icon: BarChart3 },
  { to: '/ranking', label: 'Ranking', icon: Trophy },
  { to: '/game', label: 'Jogo', icon: Gamepad2 },
  { to: '/questions', label: 'Questões', icon: HelpCircle },
  { to: '/students', label: 'Alunos', icon: GraduationCap },
  { to: '/classes', label: 'Turmas', icon: Users },
  { to: '/teachers', label: 'Professores', icon: UserSquare2 },
  { to: '/schools', label: 'Escolas', icon: School },
  { to: '/bands', label: 'Pulseiras', icon: Watch },
];

export default function Layout() {
  const { pathname } = useLocation();
  return (
    <div className="min-h-screen bg-background text-foreground">
      <div className="pointer-events-none fixed inset-x-0 top-0 h-64 bg-gradient-to-b from-amber-500/10 to-transparent" />
      <header className="sticky top-0 z-30 backdrop-blur-xl bg-background/80 border-b border-border">
        <div className="max-w-6xl mx-auto px-5 h-16 flex items-center justify-between">
          <Link to="/" className="flex items-center gap-2.5">
            <span className="w-8 h-8 rounded-lg bg-gradient-to-br from-amber-400 to-orange-600 flex items-center justify-center">
              <Radio className="w-4 h-4 text-black" />
            </span>
            <span className="text-[15px] tracking-[0.2em] font-semibold">INVOKE<span className="text-amber-400"> BAND</span></span>
          </Link>
          <div className="flex items-center gap-1">
            <ThemeToggle />
            <button
              onClick={() => base44.auth.logout()}
              className="p-2 rounded-full text-muted-foreground hover:text-foreground transition-colors"
              aria-label="Sair"
            >
              <LogOut className="w-4 h-4" />
            </button>
          </div>
        </div>
        <nav className="max-w-6xl mx-auto px-3 pb-2 flex gap-1 overflow-x-auto scrollbar-none">
          {NAV.map(({ to, label, icon: Icon }) => {
            const active = pathname === to;
            return (
              <Link
                key={to}
                to={to}
                className={`shrink-0 flex items-center gap-1.5 px-3 py-1.5 rounded-full text-[13px] transition-all duration-300 ${
                  active ? 'bg-primary text-primary-foreground' : 'text-muted-foreground hover:text-foreground hover:bg-muted'
                }`}
              >
                <Icon className="w-3.5 h-3.5" />
                {label}
              </Link>
            );
          })}
        </nav>
      </header>
      <main className="max-w-6xl mx-auto px-5 py-8 relative">
        <Outlet />
      </main>
    </div>
  );
}