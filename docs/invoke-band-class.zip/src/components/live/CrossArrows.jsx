import React from 'react';

// Seta em bloco (viewBox 48x48), contorno âmbar com brilho neon.
// `active` preenche o corpo e intensifica o brilho.
const PATH_UP = 'M24 2 L44 20 L36 20 L36 46 L12 46 L12 20 Z';

const ANGLE = { up: 0, right: 90, down: 180, left: 270 };
const LETTER_POS = {
  up: { x: 24, y: 34 },
  right: { x: 15, y: 24 },
  down: { x: 24, y: 14 },
  left: { x: 34, y: 24 },
};

export function CrossArrow({ dir, letter, active }) {
  const angle = ANGLE[dir] ?? 0;
  const pos = LETTER_POS[dir] || LETTER_POS.up;
  return (
    <svg viewBox="0 0 48 48" className="w-full h-full">
      <g transform={`rotate(${angle} 24 24)`}>
        <path
          d={PATH_UP}
          fill={active ? 'rgba(255,179,71,0.28)' : 'transparent'}
          stroke="#FFB347"
          strokeWidth="2"
          strokeLinejoin="round"
          style={{
            filter: active
              ? 'drop-shadow(0 0 7px rgba(255,179,71,0.95))'
              : 'drop-shadow(0 0 3px rgba(255,179,71,0.4))',
          }}
        />
      </g>
      <text
        x={pos.x}
        y={pos.y}
        textAnchor="middle"
        dominantBaseline="central"
        fontSize="15"
        fontWeight="800"
        fill="#FFFFFF"
      >
        {letter}
      </text>
    </svg>
  );
}

// Layout em cruz: up no topo, left/right nas laterais, down embaixo.
// A letra de cada posição vem do mapeamento de direções da questão.
export default function CrossArrows({ question, activeDir }) {
  const LETTERS = ['A', 'B', 'C', 'D'];
  const byDir = {};
  LETTERS.forEach((l) => {
    const d = String(question?.[`answer_${l.toLowerCase()}_dir`] || '').toLowerCase();
    if (d) byDir[d] = l;
  });
  return (
    <div className="grid grid-cols-3 grid-rows-3 gap-1 w-full max-w-[180px]">
      <div className="col-start-2 row-start-1 h-14"><CrossArrow dir="up" letter={byDir.up || 'A'} active={activeDir === 'up'} /></div>
      <div className="col-start-1 row-start-2 h-14"><CrossArrow dir="left" letter={byDir.left || 'C'} active={activeDir === 'left'} /></div>
      <div className="col-start-3 row-start-2 h-14"><CrossArrow dir="right" letter={byDir.right || 'D'} active={activeDir === 'right'} /></div>
      <div className="col-start-2 row-start-3 h-14"><CrossArrow dir="down" letter={byDir.down || 'B'} active={activeDir === 'down'} /></div>
    </div>
  );
}