import React, { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Bluetooth, Loader2 } from 'lucide-react';
import { scanBand } from '@/lib/ble';

export default function RecordForm({ fields, initial, onSubmit, onCancel }) {
  const [values, setValues] = useState(initial || {});
  const [saving, setSaving] = useState(false);
  const [scanning, setScanning] = useState(false);
  const [error, setError] = useState('');

  const set = (k, v) => setValues((p) => ({ ...p, [k]: v }));

  const handleScan = async () => {
    setError('');
    setScanning(true);
    try {
      const d = await scanBand();
      set('mac_address', d.mac_address);
      if (!values.device_code) set('device_code', d.name);
    } catch (e) {
      setError(e.message || 'Não foi possível ler o dispositivo.');
    }
    setScanning(false);
  };

  const submit = async (e) => {
    e.preventDefault();
    setSaving(true);
    await onSubmit(values);
    setSaving(false);
  };

  return (
    <form onSubmit={submit} className="space-y-4">
      <div className="grid sm:grid-cols-2 gap-4">
        {fields.map((f) => (
          <div key={f.name} className={f.type === 'textarea' ? 'sm:col-span-2' : ''}>
            <Label className="text-[11px] uppercase tracking-wider text-muted-foreground">{f.label}</Label>
            {f.type === 'select' ? (
              <select
                value={values[f.name] ?? ''}
                onChange={(e) => set(f.name, e.target.value)}
                required={f.required}
                className="mt-1.5 w-full h-10 rounded-md bg-background border border-border px-3 text-sm text-foreground focus:outline-none focus:border-amber-400/60"
              >
                <option value="" className="bg-popover">—</option>
                {(f.options || []).map((o) => (
                  <option key={o.value} value={o.value} className="bg-popover">{o.label}</option>
                ))}
              </select>
            ) : f.type === 'textarea' ? (
              <Textarea
                value={values[f.name] ?? ''}
                onChange={(e) => set(f.name, e.target.value)}
                required={f.required}
                rows={3}
                className="mt-1.5 bg-background border-border text-foreground"
              />
            ) : (
              <div className="flex gap-2 mt-1.5">
                <Input
                  type={f.type === 'number' ? 'number' : f.type === 'date' ? 'date' : 'text'}
                  value={values[f.name] ?? ''}
                  onChange={(e) => set(f.name, f.type === 'number' ? Number(e.target.value) : e.target.value)}
                  required={f.required}
                  className="bg-background border-border text-foreground"
                />
                {f.ble && (
                  <Button type="button" variant="outline" onClick={handleScan} className="border-amber-400/40 text-amber-300 hover:bg-amber-400/10 shrink-0">
                    {scanning ? <Loader2 className="w-4 h-4 animate-spin" /> : <Bluetooth className="w-4 h-4" />}
                  </Button>
                )}
              </div>
            )}
          </div>
        ))}
      </div>
      {error && <p className="text-xs text-red-400">{error}</p>}
      <div className="flex justify-end gap-2 pt-2">
        <Button type="button" variant="ghost" onClick={onCancel} className="text-muted-foreground">Cancelar</Button>
        <Button type="submit" disabled={saving} className="bg-amber-400 text-black hover:bg-amber-300">
          {saving ? 'Salvando...' : 'Salvar'}
        </Button>
      </div>
    </form>
  );
}