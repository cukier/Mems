import React from 'react';
import { ArrowUp, ArrowDown, ArrowLeft, ArrowRight } from 'lucide-react';

export const DIRECTIONS = [
  { value: 'up', label: 'Cima ↑' },
  { value: 'down', label: 'Baixo ↓' },
  { value: 'left', label: 'Esquerda ←' },
  { value: 'right', label: 'Direita →' },
];

export default function DirectionArrow({ dir, className = 'w-4 h-4' }) {
  const Icon = { up: ArrowUp, down: ArrowDown, left: ArrowLeft, right: ArrowRight }[dir] || ArrowUp;
  return <Icon className={className} />;
}