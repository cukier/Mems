import React, { useEffect, useState, useRef } from 'react';
import { base44 } from '@/api/base44Client';
import { Button } from '@/components/ui/button';
import { Send, Loader2, Bluetooth, Check, Plug, PlugZap } from 'lucide-react';
import DeviceScanner from '@/components/live/DeviceScanner';
import WatchPreview from '@/components/live/WatchPreview';
import ResultsPanel from '@/components/live/ResultsPanel';
import { connectMeshNode, buildDispatch, directionToLetter, CAPTURE_MS, bleSupported } from '@/lib/ble';

export default function Live() {
  const [classes, setClasses] = useState([]);
  const [questions, setQuestions] = useState([]);
  const [classId, setClassId] = useState('');
  const [questionId, setQuestionId] = useState('');
  const [phase, setPhase] = useState('idle');
  const [countdown, setCountdown] = useState(5);
  const [results, setResults] = useState([]);
  const [hubConnected, setHubConnected] = useState(false);
  const [hubBusy, setHubBusy] = useState(false);
  const [hubError, setHubError] = useState('');

  const stopHubRef = useRef(async () => {});
  const sendRef = useRef(null); // envia comandos ao nó mesh (disparo de questão)
  const gesturesRef = useRef({}); // band_number -> última direção detectada

  useEffect(() => {
    (async () => {
      setClasses(await base44.entities.SchoolClass.list());
      setQuestions(await base44.entities.Question.list('-created_date'));
    })();
    // desconecta o hub ao sair da página
    return () => { try { stopHubRef.current(); } catch {} };
  }, []);

  const question = questions.find((q) => q.id === questionId);

  // Conecta o hub UMA vez e mantém a conexão viva entre questões.
  const connectHub = async () => {
    setHubError('');
    setHubBusy(true);
    try {
      const { send, stop } = await connectMeshNode(
        ({ band, dir }) => { if (dir) gesturesRef.current[band || ''] = dir; },
        (err) => {
          setHubConnected(false);
          sendRef.current = null;
          setHubError(err?.message || 'Nó da rede mesh desconectado.');
        }
      );
      stopHubRef.current = stop;
      sendRef.current = send;
      setHubConnected(true);
    } catch (e) {
      setHubError(e?.message || 'Não foi possível conectar ao nó da rede mesh.');
      setHubConnected(false);
    }
    setHubBusy(false);
  };

  const disconnectHub = async () => {
    try { await stopHubRef.current(); } catch {}
    stopHubRef.current = async () => {};
    sendRef.current = null;
    setHubConnected(false);
    gesturesRef.current = {};
  };

  const start = async () => {
    if (!question) return;
    if (!classId) { setHubError('Selecione a turma — a questão é disparada só para ela.'); return; }
    if (!hubConnected) { setHubError('Conecte o nó da rede mesh primeiro.'); return; }
    setResults([]);
    setHubError('');

    // A questão é endereçada apenas às pulseiras dos alunos da turma selecionada.
    const students = await base44.entities.Student.filter({ class_id: classId });
    const bandNumbers = [...new Set(
      students.map((s) => String(s.band_number || '').trim()).filter(Boolean)
    )];
    if (!bandNumbers.length) {
      setHubError('Nenhum aluno desta turma tem pulseira vinculada.');
      return;
    }

    // Dispara a questão no mesh (o gabarito nunca é enviado às pulseiras).
    try {
      await sendRef.current?.(buildDispatch(question, bandNumbers, 5));
    } catch (e) {
      setHubError(e?.message || 'Falha ao disparar a questão no mesh.');
      return;
    }

    // limpa gestos anteriores antes da janela de captura
    gesturesRef.current = {};

    setPhase('countdown');
    for (let n = 5; n >= 1; n--) {
      setCountdown(n);
      await new Promise((r) => setTimeout(r, 1000));
    }
    setPhase('go');

    await new Promise((r) => setTimeout(r, CAPTURE_MS));

    // o snapshot pode conter gestos de qualquer pulseira do mesh; contamos
    // apenas os alunos da turma selecionada (busca pelo nº da pulseira).
    const snapshot = { ...gesturesRef.current };

    const captured = students.map((s) => {
      const dir = snapshot[String(s.band_number || '').trim()];
      const letter = dir ? directionToLetter(question, dir) : null;
      return {
        student_id: s.id,
        student_name: s.name,
        band_number: s.band_number,
        answer: letter,
        direction: dir,
        is_correct: letter != null && letter === question.correct,
      };
    });

    setResults(captured);
    setPhase('idle');

    if (captured.length) {
      await base44.entities.QuizSession.create({
        class_id: classId,
        question_id: question.id,
        statement: question.statement,
        correct: question.correct,
        results: captured,
      });
    }
  };

  const running = phase !== 'idle';

  return (
    <div>
      <h1 className="text-3xl font-light tracking-tight">Sessão ao vivo</h1>
      <p className="text-sm text-muted-foreground mt-1">Envie a questão e capture as respostas pelo movimento das pulseiras.</p>

      <div className="grid lg:grid-cols-2 gap-6 mt-8">
        <div className="space-y-4">
          <div className="rounded-2xl border border-border bg-card p-5 space-y-4">
            <div>
              <label className="text-[11px] uppercase tracking-wider text-muted-foreground">Turma</label>
              <select
                value={classId}
                onChange={(e) => setClassId(e.target.value)}
                className="mt-1.5 w-full h-10 rounded-md bg-background border border-border px-3 text-sm text-foreground focus:outline-none focus:border-amber-400/60"
              >
                <option value="" className="bg-popover">Selecione a turma</option>
                {classes.map((c) => (
                  <option key={c.id} value={c.id} className="bg-popover">{c.name} {c.period ? `(${c.period})` : ''}</option>
                ))}
              </select>
            </div>
            <div>
              <label className="text-[11px] uppercase tracking-wider text-muted-foreground">Questão</label>
              <select
                value={questionId}
                onChange={(e) => setQuestionId(e.target.value)}
                className="mt-1.5 w-full h-10 rounded-md bg-background border border-border px-3 text-sm text-foreground focus:outline-none focus:border-amber-400/60"
              >
                <option value="" className="bg-popover">Selecione</option>
                {questions.map((q) => (
                  <option key={q.id} value={q.id} className="bg-popover">{q.statement.slice(0, 60)}</option>
                ))}
              </select>
            </div>

            {/* Conexão do hub — feita uma vez, reutilizada em todas as questões */}
            <div className="flex items-center justify-between gap-3 rounded-lg border border-border bg-background/40 px-3 py-2.5">
              <div className="flex items-center gap-2 min-w-0">
                <span className={`w-2 h-2 rounded-full shrink-0 ${hubConnected ? 'bg-emerald-400' : 'bg-muted-foreground/40'}`} />
                <div className="min-w-0">
                  <p className="text-xs font-medium truncate">Rede mesh BLE</p>
                  <p className="text-[11px] text-muted-foreground truncate">
                    {hubConnected ? 'Nó conectado — as pulseiras se retransmitem' : 'Nó não conectado'}
                  </p>
                </div>
              </div>
              {hubConnected ? (
                <Button onClick={disconnectHub} variant="outline" size="sm" className="shrink-0">
                  <PlugZap className="w-3.5 h-3.5 mr-1" /> Desconectar
                </Button>
              ) : (
                <Button onClick={connectHub} disabled={hubBusy || !bleSupported()} variant="outline" size="sm" className="border-amber-400/40 text-amber-300 hover:bg-amber-400/10 shrink-0">
                  {hubBusy ? <Loader2 className="w-3.5 h-3.5 animate-spin mr-1" /> : <Plug className="w-3.5 h-3.5 mr-1" />}
                  {hubBusy ? 'Conectando...' : 'Conectar nó'}
                </Button>
              )}
            </div>

            <Button onClick={start} disabled={!question || !classId || running || !hubConnected} className="w-full bg-amber-400 text-black hover:bg-amber-300 h-11 rounded-xl">
              {running ? <Loader2 className="w-4 h-4 animate-spin mr-2" /> : <Send className="w-4 h-4 mr-2" />}
              {running ? 'Em andamento...' : 'Enviar para as pulseiras'}
            </Button>
            {hubError && (
              <p className="text-xs text-red-400 -mt-1">{hubError}</p>
            )}
          </div>

          <DeviceScanner />
          <ResultsPanel results={results} correct={question?.correct} />
        </div>

        <WatchPreview question={question} phase={phase} countdown={countdown} />
      </div>
    </div>
  );
}