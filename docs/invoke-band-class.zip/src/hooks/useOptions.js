import { useEffect, useState } from 'react';
import { base44 } from '@/api/base44Client';

export default function useOptions(entity, labelFn) {
  const [options, setOptions] = useState([]);
  useEffect(() => {
    let alive = true;
    base44.entities[entity].list().then((rows) => {
      if (alive) setOptions(rows.map((r) => ({ value: r.id, label: labelFn(r) })));
    });
    return () => { alive = false; };
  }, [entity]);
  return options;
}