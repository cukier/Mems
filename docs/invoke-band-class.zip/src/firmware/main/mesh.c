// Mesh por flooding no advertising: as mensagens (perguntas e gestos) viajam
// no manufacturer data dos pacotes de advertising e cada nó retransmite as que
// recebe (hop limitado), cobrindo a sala sem provisionamento BLE-Mesh.
//
// Formatos (manufacturer data, company id 0xFFFF):
//   Q: 'Q', cd, hop, bitmap[8]   (bitmap das pulseiras 1..64 da turma)
//   G: 'G', banda, dir, hop, seq (dir 'u'/'d'/'l'/'r')
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "freertos/FreeRTOS.h"
#include "freertos/task.h"
#include "freertos/queue.h"
#include "freertos/semphr.h"
#include "esp_timer.h"
#include "esp_random.h"
#include "esp_log.h"
#include "cJSON.h"
#include "host/ble_gap.h"
#include "host/ble_hs.h"
#include "nus.h"
#include "mesh.h"

#define MFR_ID          0xFFFF
#define HOP_DEFAULT     2
#define MSG_ADV_MS      1200   // quanto tempo o adv carrega a mensagem
#define BAND_MAX        64

static const char *TAG = "mesh";

typedef struct {
    uint8_t type;    // 'Q' ou 'G'
    uint8_t cd;
    uint8_t hop;
    uint8_t band;
    uint8_t dir;
    uint8_t seq;
    uint64_t bitmap;
} mesh_evt_t;

static uint8_t g_band;
static QueueHandle_t g_evtq;
static SemaphoreHandle_t g_adv_mtx;
static volatile bool g_started = false;
static volatile bool g_adv_on = false;
static int64_t g_revert_at_us = 0;

static uint8_t g_last_seq[BAND_MAX + 1];      // dedupe de gestos por banda
static uint8_t g_seq = 0;
static uint64_t g_last_q_key = 0;
static int64_t g_last_q_us = 0;

static void (*g_qcb)(uint8_t, uint64_t);
static void (*g_gcb)(uint8_t, char);

static int gap_event(struct ble_gap_event *ev, void *arg);

// ---------- advertising ----------

// UUID do serviço NUS (little-endian) — vai no advertising para o app filtrar
// só as pulseiras INVOKE no seletor do Chrome.
static const ble_uuid128_t g_nus_svc_uuid =
    BLE_UUID128_INIT(0x9e, 0xca, 0xdc, 0x24, 0x0e, 0xe5, 0xa9, 0xe0,
                     0x93, 0xf3, 0xa3, 0xb5, 0x01, 0x40, 0xe4, 0x6e);

// ADV: flags + UUID do serviço NUS (21 bytes). O seletor do Chrome filtra por
// este UUID — placas com outro firmware nem aparecem no app.
static uint8_t build_adv(uint8_t *out)
{
    uint8_t *p = out;
    *p++ = 0x02; *p++ = 0x01; *p++ = 0x06;              // flags
    *p++ = 0x11; *p++ = 0x06;                           // UUID 128-bit (16 bytes)
    memcpy(p, g_nus_svc_uuid.value, 16); p += 16;
    return (uint8_t)(p - out);
}

// Scan response: nome "INVOKE-xx" + manufacturer data opcional
// (Q ocupa 27 bytes, G ocupa 20 — dentro do limite de 31).
static uint8_t build_scan_rsp(uint8_t *out, const uint8_t *mfr, uint8_t mlen)
{
    char name[16];
    uint8_t *p = out;
    uint8_t nl;

    snprintf(name, sizeof name, "INVOKE-%02u", g_band);
    nl = (uint8_t)strlen(name);

    *p++ = nl + 1; *p++ = 0x09;                          // nome
    memcpy(p, name, nl); p += nl;
    if (mlen) {
        *p++ = mlen + 3; *p++ = 0xFF;                    // manufacturer data
        *p++ = MFR_ID & 0xFF; *p++ = (MFR_ID >> 8) & 0xFF;
        memcpy(p, mfr, mlen); p += mlen;
    }
    return (uint8_t)(p - out);
}

// (Re)aplica o advertising com o payload dado (NULL = só nome).
static void adv_apply(const uint8_t *mfr, uint8_t mlen)
{
    uint8_t adv[31], rsp[31];
    uint8_t alen = build_adv(adv);
    uint8_t rlen = build_scan_rsp(rsp, mfr, mlen);
    struct ble_gap_adv_params ap = { 0 };
    int rc;

    ap.conn_mode = BLE_GAP_CONN_MODE_UND;
    ap.disc_mode = BLE_GAP_DISC_MODE_GEN;
    ap.itvl_min = 0x20;
    ap.itvl_max = 0x40;

    xSemaphoreTake(g_adv_mtx, portMAX_DELAY);
    if (g_adv_on) ble_gap_adv_stop();
    rc = ble_gap_adv_set_data(adv, alen);
    if (rc == 0) rc = ble_gap_adv_set_scan_data(rsp, rlen);
    if (rc == 0) {
        rc = ble_gap_adv_start(BLE_OWN_ADDR_PUBLIC, NULL, BLE_HS_FOREVER,
                               &ap, gap_event, NULL);
    }
    g_adv_on = (rc == 0);
    xSemaphoreGive(g_adv_mtx);
}

// Troca o advertising para carregar uma mensagem e agenda o retorno ao normal.
static void adv_msg(const uint8_t *mfr, uint8_t mlen)
{
    adv_apply(mfr, mlen);
    g_revert_at_us = esp_timer_get_time() + (int64_t)MSG_ADV_MS * 1000;
}

// ---------- eventos do GAP (adv + scan) ----------

static void handle_disc(struct ble_gap_event *ev)
{
    const uint8_t *d = ev->disc.data;
    uint16_t dl = ev->disc.length_data;
    uint16_t i = 0;

    while (i + 1 < dl) {
        uint8_t flen = d[i];
        if (flen == 0 || (uint16_t)(i + 1 + flen) > dl) break;
        if (d[i + 1] == 0xFF && flen >= 4) {
            uint16_t cid = d[i + 2] | (d[i + 3] << 8);
            const uint8_t *mp = &d[i + 4];
            uint8_t ml = (uint8_t)(flen - 3);   // payload após type + cid

            if (cid == MFR_ID && ml >= 1 && (mp[0] == 'Q' || mp[0] == 'G')) {
                mesh_evt_t e = { 0 };
                e.type = mp[0];
                if (e.type == 'Q' && ml >= 11) {
                    e.cd = mp[1]; e.hop = mp[2];
                    memcpy(&e.bitmap, &mp[3], 8);
                    xQueueSend(g_evtq, &e, 0);
                } else if (e.type == 'G' && ml >= 5) {
                    e.band = mp[1]; e.dir = mp[2]; e.hop = mp[3]; e.seq = mp[4];
                    if (e.band >= 1 && e.band <= BAND_MAX) xQueueSend(g_evtq, &e, 0);
                }
            }
        }
        i += 1 + flen;
    }
}

static int gap_event(struct ble_gap_event *ev, void *arg)
{
    switch (ev->type) {
    case BLE_GAP_EVENT_CONNECT:
        if (ev->connect.status == 0) {
            ESP_LOGI(TAG, "app conectado (proxy)");
            nus_set_conn(ev->connect.conn_handle);
        }
        // continua anunciando: o app conectou, mas o mesh segue vivo
        adv_apply(NULL, 0);
        break;
    case BLE_GAP_EVENT_DISCONNECT:
        nus_set_conn(0);
        adv_apply(NULL, 0);
        break;
    case BLE_GAP_EVENT_DISC:
        if (g_started) handle_disc(ev);
        break;
    default:
        break;
    }
    return 0;
}

// ---------- task do mesh ----------

static bool is_member(uint64_t bitmap)
{
    return g_band >= 1 && g_band <= BAND_MAX && ((bitmap >> (g_band - 1)) & 1);
}

static void retransmit(mesh_evt_t *e)
{
    // jitter evita colisão quando vários nós retransmitem juntos
    vTaskDelay(pdMS_TO_TICKS(10 + esp_random() % 40));
    if (e->type == 'Q') {
        uint8_t pl[11] = { 'Q', e->cd, (uint8_t)(e->hop - 1) };
        memcpy(&pl[3], &e->bitmap, 8);
        adv_msg(pl, 11);
    } else {
        uint8_t pl[5] = { 'G', e->band, e->dir, (uint8_t)(e->hop - 1), e->seq };
        adv_msg(pl, 5);
    }
}

static void mesh_task(void *arg)
{
    mesh_evt_t e;
    for (;;) {
        if (xQueueReceive(g_evtq, &e, pdMS_TO_TICKS(50))) {
            if (e.type == 'Q') {
                uint64_t key = e.bitmap ^ ((uint64_t)e.cd << 60);
                int64_t now = esp_timer_get_time();
                bool new_q = (key != g_last_q_key) || (now - g_last_q_us > 3000000LL);
                if (new_q) {
                    g_last_q_key = key;
                    g_last_q_us = now;
                    ESP_LOGI(TAG, "pergunta cd=%u hop=%u", e.cd, e.hop);
                    if (is_member(e.bitmap) && g_qcb) g_qcb(e.cd, e.bitmap);
                    if (e.hop > 0) retransmit(&e);
                }
            } else if (e.type == 'G') {
                if (g_last_seq[e.band] != e.seq) {   // dedupe
                    g_last_seq[e.band] = e.seq;
                    ESP_LOGI(TAG, "gesto banda=%u dir=%c", e.band, (char)e.dir);
                    if (g_gcb) g_gcb(e.band, (char)e.dir);
                    if (e.hop > 0) retransmit(&e);
                }
            }
        }
        // fim do anúncio de uma mensagem → volta ao advertising normal
        if (g_revert_at_us && esp_timer_get_time() >= g_revert_at_us) {
            g_revert_at_us = 0;
            adv_apply(NULL, 0);
        }
    }
}

// ---------- API ----------

void mesh_init(uint8_t band_number)
{
    g_band = band_number;
    memset(g_last_seq, 0, sizeof g_last_seq);
    g_evtq = xQueueCreate(16, sizeof(mesh_evt_t));
    g_adv_mtx = xSemaphoreCreateMutex();
    xTaskCreate(mesh_task, "mesh", 6144, NULL, 5, NULL);
}

void mesh_start(void)
{
    g_started = true;
    adv_apply(NULL, 0);
    struct ble_gap_disc_params dp = { 0 };
    dp.passive = 1;
    dp.filter_duplicates = 0;   // não filtrar: as retransmissões importam
    int rc = ble_gap_disc(BLE_OWN_ADDR_PUBLIC, BLE_HS_FOREVER, &dp,
                          gap_event, NULL);
    ESP_LOGI(TAG, "scan iniciado rc=%d", rc);
}

void mesh_set_question_cb(void (*cb)(uint8_t, uint64_t)) { g_qcb = cb; }
void mesh_set_gesture_cb(void (*cb)(uint8_t, char))      { g_gcb = cb; }

void mesh_send_gesture(char dir)
{
    uint8_t pl[5] = { 'G', g_band, (uint8_t)dir, HOP_DEFAULT, (uint8_t)++g_seq };
    g_last_seq[g_band] = g_seq;   // não ecoa o próprio gesto
    adv_msg(pl, 5);
    ESP_LOGI(TAG, "gesto enviado dir=%c seq=%u", dir, g_seq);
}

void mesh_send_question(uint8_t cd, uint64_t bitmap)
{
    // registra a própria pergunta para não reprocessar o eco das retransmissões
    g_last_q_key = bitmap ^ ((uint64_t)cd << 60);
    g_last_q_us = esp_timer_get_time();

    if (is_member(bitmap) && g_qcb) g_qcb(cd, bitmap);   // o proxy também conta

    uint8_t pl[11] = { 'Q', cd, HOP_DEFAULT };
    memcpy(&pl[3], &bitmap, 8);
    adv_msg(pl, 11);
    ESP_LOGI(TAG, "pergunta transmitida cd=%u", cd);
}

void mesh_handle_app_json(const char *json, size_t len)
{
    char *buf = malloc(len + 1);
    if (!buf) return;
    memcpy(buf, json, len);
    buf[len] = 0;

    cJSON *root = cJSON_Parse(buf);
    free(buf);
    if (!root) { ESP_LOGW(TAG, "JSON inválido do app"); return; }

    cJSON *t = cJSON_GetObjectItem(root, "t");
    if (t && cJSON_IsString(t) && strcmp(t->valuestring, "q") == 0) {
        uint8_t cd = 5;
        uint64_t bitmap = 0;
        cJSON *jcd = cJSON_GetObjectItem(root, "cd");
        if (jcd && cJSON_IsNumber(jcd) && jcd->valueint > 0 && jcd->valueint <= 60)
            cd = (uint8_t)jcd->valueint;

        cJSON *bands = cJSON_GetObjectItem(root, "bands");
        if (cJSON_IsArray(bands)) {
            cJSON *b;
            cJSON_ArrayForEach(b, bands) {
                int n = -1;
                if (cJSON_IsNumber(b)) n = b->valueint;
                else if (cJSON_IsString(b)) n = atoi(b->valuestring);
                if (n >= 1 && n <= BAND_MAX) bitmap |= (uint64_t)1 << (n - 1);
            }
        }
        if (bitmap) mesh_send_question(cd, bitmap);
        else ESP_LOGW(TAG, "pergunta sem pulseiras válidas");
    }
    cJSON_Delete(root);
}