# Firmware INVOKE (referência)

A fonte oficial do firmware é o repositório **cukier/Mems, branch `swarm-imu`**
(pasta `firmware/`). Esta pasta mantém apenas os arquivos que diferem do repo
— corrija o repo copiando estes por cima.

## Arquivos a alterar no repositório (branch swarm-imu)

1. **`firmware/main/mesh.c`** — a única mudança real. O advertising passa a
   anunciar o **UUID do serviço NUS** no pacote principal (flags + UUID
   128-bit = 21 bytes) e o nome + manufacturer data (mensagens do mesh) vão
   para o **scan response** (`ble_gap_adv_set_scan_data`).
   Por quê: o app agora filtra o seletor por esse UUID — só as pulseiras
   INVOKE aparecem, e o Chrome só aceita dispositivos que anunciam o serviço.
   Copie o `src/firmware/main/mesh.c` daqui para o repo (o resto do arquivo é
   idêntico ao do repo).

2. **`firmware/sdkconfig.defaults`** — adiciona os papéis NimBLE explicitamente:
   `CONFIG_BT_NIMBLE_ROLE_PERIPHERAL=y`, `..._BROADCASTER=y`, `..._OBSERVER=y`.

Nenhum outro arquivo do firmware precisa mudar (main.c, nus.c, st7735.c,
lsm6ds3.c, gesture.c etc. ficam como estão).

## Depois de regravar

Desligue e religue o Bluetooth do celular antes de testar — o Android guarda
em cache a tabela de serviços antiga do dispositivo (mesmo MAC regravado).