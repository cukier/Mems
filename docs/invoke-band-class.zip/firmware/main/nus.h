#pragma once
#include <stdint.h>
#include <stddef.h>

// Inicializa o módulo (após nimble_port_init).
void nus_init(void (*on_rx)(const char *json, size_t len));

// Guarda o handle da conexão (chamado pelo GAP ao conectar/desconectar).
void nus_set_conn(uint16_t conn_handle);

// Envia dados ao app via TX notify. Retorna -1 se não estiver conectado.
int nus_notify(const uint8_t *data, uint16_t len);