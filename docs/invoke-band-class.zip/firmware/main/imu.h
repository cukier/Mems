#pragma once
#include <stdbool.h>
#include "driver/i2c_master.h"

// Inicializa o MPU6050 no barramento I2C. Retorna false se ausente
// (nesse caso o botão BOOT simula gestos).
bool imu_init(i2c_master_bus_handle_t bus);

// Lê o acelerômetro e classifica um gesto. Retorna true quando houver
// um gesto novo (dir: 'u'/'d'/'l'/'r'). Chamar a cada ~10 ms.
bool imu_get_gesture(char *dir);