// MPU6050: classificação de gestos por pico de aceleração.
// Mapeamento (pulseira com tela para cima): y+ = cima, y- = baixo,
// x+ = direita, x- = esquerda; eixo z é fallback cima/baixo.
// Sem MPU6050 na bancada: o botão BOOT (GPIO9) avança
// cima → direita → baixo → esquerda a cada toque.
#include <stdbool.h>
#include "freertos/FreeRTOS.h"
#include "freertos/task.h"
#include "esp_timer.h"
#include "esp_log.h"
#include "driver/gpio.h"
#include "driver/i2c_master.h"
#include "sdkconfig.h"
#include "imu.h"

#define MPU_ADDR     0x68
#define REG_PWR      0x6B
#define REG_ACC_CFG  0x1C
#define REG_ACCEL    0x3B
#define REG_WHO      0x75
#define BTN_PIN      9

static const char *TAG = "imu";
static i2c_master_dev_handle_t g_dev;
static bool g_present = false;
static bool g_first = true;
static int16_t g_px, g_py, g_pz;
static int64_t g_last_g_us = 0;
static int64_t g_btn_last_us = 0;
static int g_cycle_i = -1;
static const char CYCLE[4] = { 'u', 'r', 'd', 'l' };

bool imu_init(i2c_master_bus_handle_t bus)
{
    // botão de teste (sempre disponível)
    gpio_config_t g = {
        .pin_bit_mask = 1ULL << BTN_PIN,
        .mode = GPIO_MODE_INPUT,
        .pull_up_en = GPIO_PULLUP_ENABLE,
    };
    gpio_config(&g);

    i2c_device_config_t dc = {
        .dev_addr_length = I2C_ADDR_BIT_LEN_7,
        .device_address = MPU_ADDR,
        .scl_speed_hz = 400000,
    };
    if (i2c_master_bus_add_device(bus, &dc, &g_dev) != ESP_OK) return false;

    uint8_t who = 0, reg = REG_WHO;
    if (i2c_master_transmit_receive(g_dev, &reg, 1, &who, 1, 100) != ESP_OK ||
        (who != 0x68 && who != 0x69 && who != 0x72 && who != 0x73)) {
        ESP_LOGW(TAG, "MPU6050 não encontrado (who=0x%02x) — usando botão", who);
        return false;
    }

    uint8_t wake[2] = { REG_PWR, 0x00 };
    uint8_t range[2] = { REG_ACC_CFG, 0x08 };   // ±4g → 8192 LSB/g
    i2c_master_transmit(g_dev, wake, 2, 100);
    i2c_master_transmit(g_dev, range, 2, 100);
    vTaskDelay(pdMS_TO_TICKS(20));

    g_present = true;
    ESP_LOGI(TAG, "MPU6050 ok");
    return true;
}

bool imu_get_gesture(char *dir)
{
    if (!g_present) {
        // modo bancada: cada toque no BOOT avança a direção
        if (gpio_get_level(BTN_PIN) == 0) {
            int64_t now = esp_timer_get_time();
            if (now - g_btn_last_us > 300000) {
                g_btn_last_us = now;
                g_cycle_i = (g_cycle_i + 1) % 4;
                *dir = CYCLE[g_cycle_i];
                return true;
            }
        }
        return false;
    }

    uint8_t reg = REG_ACCEL, d[6];
    if (i2c_master_transmit_receive(g_dev, &reg, 1, d, 6, 20) != ESP_OK)
        return false;

    int16_t ax = (int16_t)((d[0] << 8) | d[1]);
    int16_t ay = (int16_t)((d[2] << 8) | d[3]);
    int16_t az = (int16_t)((d[4] << 8) | d[5]);

    if (g_first) {   // primeira leitura: só estabelece a referência
        g_first = false;
        g_px = ax; g_py = ay; g_pz = az;
        return false;
    }
    int32_t dx = ax - g_px, dy = ay - g_py, dz = az - g_pz;
    g_px = ax; g_py = ay; g_pz = az;

    int64_t now = esp_timer_get_time();
    if (now - g_last_g_us < 400000) return false;   // debounce de 400 ms

    int32_t thresh = (int32_t)CONFIG_INVOKE_GESTURE_THRESHOLD_MG * 8192 / 1000;
    int32_t adx = dx < 0 ? -dx : dx;
    int32_t ady = dy < 0 ? -dy : dy;
    int32_t adz = dz < 0 ? -dz : dz;

    if (ady >= adx && ady >= adz && ady >= thresh) {
        *dir = dy > 0 ? 'u' : 'd';
    } else if (adx >= adz && adx >= thresh) {
        *dir = dx > 0 ? 'r' : 'l';
    } else if (adz >= thresh) {
        *dir = dz > 0 ? 'u' : 'd';
    } else {
        return false;
    }
    g_last_g_us = now;
    return true;
}