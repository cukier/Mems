// Servidor GATT Nordic UART (NUS) — é o serviço que o app INVOKE procura.
#include <string.h>
#include "host/ble_gatt.h"
#include "host/ble_uuid.h"
#include "host/ble_hs_mbuf.h"
#include "os/os_mbuf.h"
#include "nus.h"

// UUIDs 128-bit em ordem little-endian (requisito do NimBLE).
// NUS: 6e400001/02/03-b5a3-f393-e0a9-e50e24dcca9e
static const ble_uuid128_t g_svc_uuid =
    BLE_UUID128_INIT(0x9e, 0xca, 0xdc, 0x24, 0x0e, 0xe5, 0xa9, 0xe0,
                     0x93, 0xf3, 0xa3, 0xb5, 0x01, 0x40, 0xe4, 0x6e);
static const ble_uuid128_t g_rx_uuid =   // app → nó (write)
    BLE_UUID128_INIT(0x9e, 0xca, 0xdc, 0x24, 0x0e, 0xe5, 0xa9, 0xe0,
                     0x93, 0xf3, 0xa3, 0xb5, 0x02, 0x40, 0xe4, 0x6e);
static const ble_uuid128_t g_tx_uuid =   // nó → app (notify)
    BLE_UUID128_INIT(0x9e, 0xca, 0xdc, 0x24, 0x0e, 0xe5, 0xa9, 0xe0,
                     0x93, 0xf3, 0xa3, 0xb5, 0x03, 0x40, 0xe4, 0x6e);

static struct ble_gatt_chr_def g_chrs[3];
static struct ble_gatt_svc_def g_svcs[2];
static uint16_t g_tx_val_handle = 0;
static uint16_t g_conn_handle = 0;      // 0 = sem conexão
static void (*g_rx_cb)(const char *json, size_t len);

static int nus_access(uint16_t conn, uint16_t attr,
                      struct ble_gatt_access_ctxt *ctxt, void *arg)
{
    uintptr_t which = (uintptr_t)arg;

    if (which == 1 && ctxt->op == BLE_GATT_ACCESS_OP_WRITE_CHR) {
        // RX: comando do app (JSON)
        static char buf[1024];
        uint16_t len = OS_MBUF_PKTLEN(ctxt->om);
        if (len > sizeof(buf) - 1) len = sizeof(buf) - 1;
        uint16_t copied = 0;
        if (ble_hs_mbuf_to_flat(ctxt->om, buf, len, &copied) != 0) return 1;
        buf[copied] = 0;
        if (g_rx_cb) g_rx_cb(buf, copied);
        return 0;
    }
    if (which == 2 && ctxt->op == BLE_GATT_ACCESS_OP_READ_CHR) {
        return 0;  // TX legível (vazio); notificações carregam os dados
    }
    return 0;
}

void nus_init(void (*on_rx)(const char *json, size_t len))
{
    g_rx_cb = on_rx;

    g_chrs[0] = (struct ble_gatt_chr_def){
        .uuid = (ble_uuid_t *)&g_rx_uuid,
        .access_cb = nus_access,
        .arg = (void *)1,
        .flags = BLE_GATT_CHR_F_WRITE | BLE_GATT_CHR_F_WRITE_NO_RSP,
    };
    g_chrs[1] = (struct ble_gatt_chr_def){
        .uuid = (ble_uuid_t *)&g_tx_uuid,
        .access_cb = nus_access,
        .arg = (void *)2,
        .flags = BLE_GATT_CHR_F_READ | BLE_GATT_CHR_F_NOTIFY,
        .val_handle = &g_tx_val_handle,
    };
    memset(&g_chrs[2], 0, sizeof g_chrs[2]);

    g_svcs[0] = (struct ble_gatt_svc_def){
        .type = BLE_GATT_SVC_TYPE_PRIMARY,
        .uuid = (ble_uuid_t *)&g_svc_uuid,
        .characteristics = g_chrs,
    };
    memset(&g_svcs[1], 0, sizeof g_svcs[1]);

    ble_gatts_count_cfg(g_svcs);
    ble_gatts_add_svcs(g_svcs);
}

void nus_set_conn(uint16_t conn_handle)
{
    g_conn_handle = conn_handle;
}

int nus_notify(const uint8_t *data, uint16_t len)
{
    if (g_conn_handle == 0 || g_tx_val_handle == 0) return -1;
    struct os_mbuf *om = ble_hs_mbuf_from_flat(data, len);
    if (!om) return -1;
    return ble_gatts_notify_custom(g_conn_handle, g_tx_val_handle, om);
}