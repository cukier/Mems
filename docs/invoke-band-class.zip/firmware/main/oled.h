#pragma once
#include <stdbool.h>
#include "driver/i2c_master.h"

// Inicializa o OLED SSD1306 128x64 no barramento. Retorna false se ausente
// (as demais funções viram no-op).
bool oled_init(i2c_master_bus_handle_t bus);

void oled_clear(void);
void oled_text(int x, int y, int scale, const char *str);
void oled_show(void);