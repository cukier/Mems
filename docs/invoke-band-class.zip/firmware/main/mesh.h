#pragma once
#include <stdint.h>
#include <stddef.h>

// Inicializa o módulo (não depende do BLE ainda estar sincronizado).
void mesh_init(uint8_t band_number);

// Chamado quando o BLE sincroniza: inicia advertising + scan.
void mesh_start(void);

// Pergunta endereçada a esta pulseira (cd = segundos de contagem).
void mesh_set_question_cb(void (*cb)(uint8_t cd, uint64_t bitmap));

// Todo gesto recebido no mesh (para o proxy repassar ao app).
void mesh_set_gesture_cb(void (*cb)(uint8_t band, char dir));

// Publica um gesto desta pulseira no mesh (dir: 'u'/'d'/'l'/'r').
void mesh_send_gesture(char dir);

// Proxy: recebe o JSON do app e transmite a pergunta no mesh.
void mesh_send_question(uint8_t cd, uint64_t bitmap);

// Proxy: interpreta o JSON de disparo vindo do app ({"t":"q",...}).
void mesh_handle_app_json(const char *json, size_t len);