// INVOKE Band — nó/pulseira ESP32-C3.
// Estados: standby → contagem regressiva → VÁ!/captura (8 s) → confirmação.
// Qualquer pulseira conectada ao app (NUS) vira o proxy do mesh.
#include <stdio.h>
#include <string.h>
#include "freertos/FreeRTOS.h"
#include "freertos/task.h"
#include "freertos/queue.h"
#include "esp_log.h"
#include "esp_timer.h"
#include "nvs_flash.h"
#include "nvs.h"
#include "driver/i2c_master.h"

#include "nimble/nimble_port.h"
#include "nimble/nimble_port_freertos.h"
#include "host/ble_hs.h"
#include "services/gap/ble_svc_gap.h"

#include "sdkconfig.h"
#include "oled.h"
#include "imu.h"
#include "mesh.h"
#include "nus.h"

#define CAPTURE_WINDOW_MS 8000
#define CONFIRM_MS        900

static const char *TAG = "invoke";

typedef enum { ST_IDLE = 0, ST_COUNTDOWN, ST_CAPTURE } st_t;
typedef struct { uint8_t cd; } q_msg_t;

static QueueHandle_t s_qq;
static volatile st_t s_state = ST_IDLE;
static int64_t s_phase_us = 0;
static int64_t s_conf_until_us = 0;
static uint8_t s_cd = 5;
static int s_drawn = -1;
static uint8_t s_band;

// ---------- telas ----------

static void standby_screen(void)
{
    char l1[16];
    snprintf(l1, sizeof l1, "INVOKE-%02u", s_band);
    oled_clear();
    oled_text(4, 16, 2, l1);
    oled_show();
}

static void countdown_screen(int rem)
{
    char buf[4];
    snprintf(buf, sizeof buf, "%d", rem);
    oled_clear();
    oled_text(52, 4, 8, buf);
    oled_show();
}

static void go_screen(void)
{
    oled_clear();
    oled_text(48, 12, 3, "VA!");
    oled_text(34, 52, 1, "U R D L");
    oled_show();
}

static void confirm_screen(char dir)
{
    char buf[2] = { dir, 0 };
    oled_clear();
    oled_text(16, 8, 2, "ENVIADO");
    oled_text(58, 36, 3, buf);
    oled_show();
}

// ---------- callbacks do mesh ----------

static void on_question(uint8_t cd, uint64_t bitmap)
{
    // o mesh já filtrou: só chega se esta pulseira está na turma
    q_msg_t m = { .cd = cd };
    xQueueSend(s_qq, &m, 0);
    ESP_LOGI(TAG, "pergunta para mim! cd=%u", cd);
}

static void on_gesture(uint8_t band, char dir)
{
    // proxy: repassa o gesto do mesh ao app
    char json[48];
    int n = snprintf(json, sizeof json, "{\"b\":\"%u\",\"d\":\"%c\"}", band, dir);
    nus_notify((const uint8_t *)json, n);
}

// ---------- NimBLE ----------

static void on_sync(void)
{
    char name[16];
    snprintf(name, sizeof name, "INVOKE-%02u", s_band);
    ble_svc_gap_device_name_set(name);
    mesh_start();
}

static void on_reset(int reason)
{
    ESP_LOGW(TAG, "ble reset: %d", reason);
}

static void host_task(void *param)
{
    nimble_port_run();
    nimble_port_freertos_deinit();
}

// ---------- tarefa principal (estado + IMU + display) ----------

static void main_task(void *arg)
{
    char dir;
    for (;;) {
        vTaskDelay(pdMS_TO_TICKS(10));
        int64_t now = esp_timer_get_time();

        // pergunta recebida (sai de ST_IDLE)
        q_msg_t m;
        while (xQueueReceive(s_qq, &m, 0)) {
            if (s_state == ST_IDLE) {
                s_cd = m.cd;
                s_state = ST_COUNTDOWN;
                s_phase_us = now;
                s_drawn = -1;
            }
        }

        // gesto dentro da janela de captura
        if (imu_get_gesture(&dir)) {
            if (s_state == ST_CAPTURE) {
                mesh_send_gesture(dir);
                confirm_screen(dir);
                s_conf_until_us = now + (int64_t)CONFIRM_MS * 1000;
            }
        }

        if (s_state == ST_COUNTDOWN) {
            int rem = (int)s_cd - (int)((now - s_phase_us) / 1000000LL);
            if (rem <= 0) {
                s_state = ST_CAPTURE;
                s_phase_us = now;
                s_conf_until_us = 0;
                go_screen();
                ESP_LOGI(TAG, "VA! janela de captura aberta");
            } else if (rem != s_drawn) {
                s_drawn = rem;
                countdown_screen(rem);
            }
        } else if (s_state == ST_CAPTURE) {
            if (now - s_phase_us > (int64_t)CAPTURE_WINDOW_MS * 1000LL) {
                s_state = ST_IDLE;
                standby_screen();
                ESP_LOGI(TAG, "janela encerrada");
            } else if (s_conf_until_us && now >= s_conf_until_us) {
                s_conf_until_us = 0;   // fim da confirmação → volta ao "VA!"
                go_screen();
            }
        }
    }
}

// ---------- boot ----------

static uint8_t load_band_number(void)
{
    nvs_handle_t h;
    uint8_t band = 0;
    if (nvs_open("invoke", NVS_READWRITE, &h) != ESP_OK) return 1;
    if (nvs_get_u8(h, "band", &band) != ESP_OK) {
        band = (uint8_t)CONFIG_INVOKE_BAND_NUMBER;
        nvs_set_u8(h, "band", band);
        nvs_commit(h);
        ESP_LOGI(TAG, "nº da pulseira gravado na NVS: %u", band);
    }
    nvs_close(h);
    return band;
}

void app_main(void)
{
    // NVS (necessário ao NimBLE)
    esp_err_t err = nvs_flash_init();
    if (err == ESP_ERR_NVS_NO_FREE_PAGES || err == ESP_ERR_NVS_NEW_VERSION_FOUND) {
        nvs_flash_erase();
        nvs_flash_init();
    }

    s_band = load_band_number();

    // barramento I2C compartilhado (OLED + IMU)
    i2c_master_bus_config_t bcfg = {
        .i2c_port = 0,
        .sda_io_num = CONFIG_INVOKE_I2C_SDA,
        .scl_io_num = CONFIG_INVOKE_I2C_SCL,
        .clk_source = I2C_CLK_SRC_DEFAULT,
        .glitch_ignore_cnt = 7,
        .flags.enable_internal_pullup = true,
    };
    i2c_master_bus_handle_t bus = NULL;
    if (i2c_new_master_bus(&bcfg, &bus) == ESP_OK) {
        bool oled_ok = oled_init(bus);
        bool imu_ok = imu_init(bus);
        if (oled_ok) standby_screen();
        ESP_LOGI(TAG, "pulseira %u | oled=%d imu=%d (sem IMU use o BOOT)",
                 s_band, oled_ok, imu_ok);
    } else {
        ESP_LOGW(TAG, "I2C indisponível — só BLE");
    }

    s_qq = xQueueCreate(4, sizeof(q_msg_t));

    // NimBLE + NUS (o serviço que o app procura)
    nimble_port_init();
    ble_hs_cfg.sync_cb = on_sync;
    ble_hs_cfg.reset_cb = on_reset;

    nus_init(mesh_handle_app_json);
    mesh_init(s_band);
    mesh_set_question_cb(on_question);
    mesh_set_gesture_cb(on_gesture);

    nimble_port_freertos_init(host_task);

    xTaskCreate(main_task, "main", 4096, NULL, 5, NULL);
}