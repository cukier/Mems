# INVOKE Band — Firmware do nó ESP32-C3 (ESP-IDF 5.2+)

Firmware das pulseiras INVOKE em ESP32-C3. Cada pulseira roda o MESMO firmware
(diferenciadas apenas pelo número gravado na NVS). Qualquer pulseira pode ser o
"nó proxy" — o professor conecta o app (Web Bluetooth) em qualquer uma delas e
ela passa a fazer a ponte entre o app e as demais.

## O que está implementado

- **GATT Nordic UART (NUS)** — serviço `6e400001-b5a3-f393-e0a9-e50e24dcca9e`
  com RX (write) e TX (notify). É o serviço que o app procura ao conectar.
- **Mesh por flooding no advertising** — mensagens viajam no manufacturer data
  dos pacotes de advertising; cada pulseira retransmite as que recebe (com hop
  limitado). Sem provisionamento: só gravar e ligar.
  - Pergunta `Q`: `['Q', cd, hop, bitmap(8 bytes)]` — bitmap das pulseiras da
    turma (bits 1..64). Só quem está no bitmap entra na contagem.
  - Gesto `G`: `['G', banda, dir, hop, seq]` — dir = 'u'/'d'/'l'/'r'.
- **Proxy** — quando conectada ao app:
  - recebe `{"t":"q","bands":[...],"cd":n,...}` na RX e transmite o `Q` no mesh
    (os campos de texto `s`/`o` são ignorados — o display não mostra enunciado);
  - repassa cada gesto recebido ao app na TX como `{"b":"3","d":"up"}`.
- **MPU6050 (I2C, 0x68)** — classificação do gesto por pico de aceleração
  (dominância de eixo: y+=cima, y-=baixo, x+=direita, x-=esquerda; z é fallback
  cima/baixo). Ajuste o limiar no menuconfig.
- **SSD1306 OLED 128x64 (I2C, 0x3C)** — standby, contagem regressiva grande,
  "VA!", confirmação "ENVIADO".
- **Sem IMU?** o botão BOOT (GPIO9) simula gestos: cada toque avança
  cima → direita → baixo → esquerda (útil para testar na bancada).

## Sequência de uma rodada (igual à do app)

1. App envia o `q` ao proxy (NUS RX) → proxy transmite `Q` no mesh.
2. Só as pulseiras do bitmap iniciam a contagem de `cd` segundos (display).
3. Fim da contagem → "VA!" → janela de captura de 8 s (CAPTURE_MS do app).
4. Gesto → `G` publicado no mesh → retransmissão → proxy notifica o app.

## Compilar e gravar

```bash
idf.py set-target esp32c3
idf.py menuconfig   # menu "INVOKE Band": número da pulseira, GPIOs, limiar
idf.py build
idf.py flash monitor
```

O número da pulseira (`INVOKE_BAND_NUMBER`) é gravado na NVS no primeiro boot.
**Para trocar o número depois**, rode `idf.py erase-flash` antes de gravar.

Repita para cada pulseira mudando o número no menuconfig (1, 2, 3...). O nome
BLE aparece como `INVOKE-01`, `INVOKE-02`, ... no seletor do Chrome.

## Fiação

| Periférico | Endereço I2C | Pinos (default) |
|---|---|---|
| OLED SSD1306 128x64 | 0x3C | SDA=GPIO4, SCL=GPIO5 |
| IMU MPU6050 | 0x68 | mesmo barramento |
| Botão de teste | — | GPIO9 (BOOT) |

GPIOs configuráveis no menuconfig ("INVOKE Band").

## Notas / limitações

- Enunciados muito longos no JSON do app (> ~509 bytes) podem falhar na
  escrita GATT (limite de MTU). O firmware só usa `bands` e `cd`.
- O mesh usa advertising legado (31 bytes) com hop=2 e dedupe por sequência —
  cobre uma sala de aula sem a complexidade do ESP-BLE-Mesh/provisionamento.
- Se a conexão cair (ex. GATT 133), o app já reconecta automaticamente.